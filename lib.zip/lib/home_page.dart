import 'package:flutter/material.dart';
import 'profile_page.dart';
import 'settings_page.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;
  TextEditingController _textController = TextEditingController();

  void _onItemTapped(int index) {
    if (index != _selectedIndex) {
      Widget nextPage;
      switch (index) {
        case 1:
          nextPage = ProfilePage();
          break;
        case 2:
          nextPage = SettingsPage();
          break;
        default:
          nextPage = HomePage();
      }
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => nextPage),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("SignSpell", style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
                  Text("Sign, Aid, Spell", style: TextStyle(fontSize: 14, color: Colors.grey)),
                  SizedBox(height: 40),

                  Container(
                    padding: EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10, spreadRadius: 2)],
                    ),
                    child: Column(
                      children: [
                        Text("Sign Spell", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                        Text("Enter any text to see its finger spelling representation", 
                            style: TextStyle(fontSize: 14, color: Colors.grey),
                            textAlign: TextAlign.center),
                        SizedBox(height: 20),

                        TextField(
                          controller: _textController,
                          decoration: InputDecoration(
                            labelText: "Enter text to spell",
                            border: OutlineInputBorder(),
                            hintText: "Type anything....",
                          ),
                        ),
                        SizedBox(height: 20),

                        ElevatedButton(
                          onPressed: () {
                            // Implement logic to generate signs
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.black,
                            minimumSize: Size(double.infinity, 50),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                          child: Text("Generate Signs", style: TextStyle(color: Colors.white, fontSize: 16)),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.translate), label: "Generate"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: "Settings"),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.black,
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
      ),
    );
  }
}
