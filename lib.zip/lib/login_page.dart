import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'home_page.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  bool _isPasswordVisible = false;
  bool _isLoading = false;

  void showMessage(String message, {bool isError = true}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : Colors.green,
      ),
    );
  }

  bool isValidEmail(String email) {
    return RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]+$")
        .hasMatch(email);
  }

  Future<void> loginUser() async {
    if (emailController.text.isEmpty || passwordController.text.isEmpty) {
      showMessage("Email and password are required!");
      return;
    }

    if (!isValidEmail(emailController.text)) {
      showMessage("Invalid email format!");
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      var url = Uri.parse("http://10.0.2.2/signspell_api/login.php");
      var response = await http.post(url, body: {
        "email": emailController.text,
        "password": passwordController.text,
      });

      var data = jsonDecode(response.body);

      if (data["success"]) {
        showMessage("Login successful!", isError: false);
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => HomePage()));
      } else {
        showMessage(data["message"]);
      }
    } catch (e) {
      showMessage("Failed to connect. Check your internet.");
    }

    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // App Title
                  Text("SignSpell", style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
                  Text("Sign, Aid, Spell", style: TextStyle(fontSize: 14, color: Colors.grey)),
                  SizedBox(height: 40),

                  // Card Container
                  Container(
                    padding: EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(color: Colors.black12, blurRadius: 10, spreadRadius: 2),
                      ],
                    ),
                    child: Column(
                      children: [
                        Text("Welcome Back", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                        Text("Fill out the information below to access your account",
                            style: TextStyle(fontSize: 14, color: Colors.grey),
                            textAlign: TextAlign.center),
                        SizedBox(height: 20),

                        // Input Fields
                        TextField(
                          controller: emailController,
                          decoration: InputDecoration(labelText: "Email", border: OutlineInputBorder()),
                        ),
                        SizedBox(height: 10),
                        TextField(
                          controller: passwordController,
                          obscureText: !_isPasswordVisible,
                          decoration: InputDecoration(
                            labelText: "Password",
                            border: OutlineInputBorder(),
                            suffixIcon: IconButton(
                              icon: Icon(_isPasswordVisible ? Icons.visibility : Icons.visibility_off),
                              onPressed: () => setState(() => _isPasswordVisible = !_isPasswordVisible),
                            ),
                          ),
                        ),
                        SizedBox(height: 20),

                        // Login Button
                        ElevatedButton(
                          onPressed: _isLoading ? null : loginUser,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue,
                            minimumSize: Size(double.infinity, 50),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                          child: _isLoading
                              ? CircularProgressIndicator(color: Colors.white)
                              : Text("Sign In", style: TextStyle(color: Colors.white, fontSize: 16)),
                        ),
                        SizedBox(height: 10),

                        // Google Sign-In Button
                        ElevatedButton(
                          onPressed: () {
                            // TODO: Implement Google Sign-In
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            minimumSize: Size(double.infinity, 50),
                            side: BorderSide(color: Colors.black),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                          child: Text("Continue with Google", style: TextStyle(color: Colors.black, fontSize: 16)),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 15),

                  // Navigation to Register Page
                  GestureDetector(
                    onTap: () => Navigator.pushNamed(context, "/register"),
                    child: RichText(
                      text: TextSpan(
                        text: "Don’t have an account? ",
                        style: TextStyle(color: Colors.black),
                        children: [
                          TextSpan(
                            text: "Sign Up here",
                            style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
