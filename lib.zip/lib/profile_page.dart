import 'package:flutter/material.dart';
import 'home_page.dart';
import 'settings_page.dart';

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  int _selectedIndex = 1;

  void _onItemTapped(int index) {
    if (index != _selectedIndex) {
      Widget nextPage;
      switch (index) {
        case 0:
          nextPage = HomePage();
          break;
        case 2:
          nextPage = SettingsPage();
          break;
        default:
          nextPage = ProfilePage();
      }
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => nextPage),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Profile Header
              Text("Profile", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              SizedBox(height: 10),
              Divider(),

              // Profile Picture & Info
              Center(
                child: Column(
                  children: [
                    CircleAvatar(
                      radius: 50,
                      backgroundColor: Colors.grey[300], // Placeholder for profile pic
                      child: Icon(Icons.person, size: 50, color: Colors.grey[600]),
                    ),
                    SizedBox(height: 10),
                    Text("[Name]", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    Text("[Email]", style: TextStyle(fontSize: 14, color: Colors.grey[600])),
                    SizedBox(height: 10),

                    // Edit Profile & Logout Buttons
                    ElevatedButton(
                      onPressed: () {
                        // Implement edit profile functionality
                      },
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.black),
                      child: Text("Edit Profile", style: TextStyle(color: Colors.white)),
                    ),
                    SizedBox(height: 5),
                    TextButton(
                      onPressed: () {
                        // Implement logout functionality
                      },
                      child: Text("Log Out", style: TextStyle(color: Colors.red, fontSize: 16)),
                    ),
                  ],
                ),
              ),

              SizedBox(height: 20),

              // My Stats Section
              Text("My Stats", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.grey[700])),
              SizedBox(height: 10),

              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("[Hour]", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        Text("Screen time", style: TextStyle(fontSize: 14, color: Colors.grey[600])),
                      ],
                    ),
                    Icon(Icons.pie_chart, size: 40, color: Colors.black),
                  ],
                ),
              ),

              SizedBox(height: 20),

              // AI Feedback Section
              Text("AI Feedback", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.grey[700])),
              SizedBox(height: 10),

              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text("Generating.....", style: TextStyle(fontSize: 16, color: Colors.grey[600])),
              ),
            ],
          ),
        ),
      ),

      // Bottom Navigation Bar
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.translate), label: "Generate"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: "Settings"),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.black,
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
      ),
    );
  }
}
