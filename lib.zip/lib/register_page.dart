import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class RegisterPage extends StatefulWidget {
  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();

  bool _isPasswordVisible = false;
  bool _isConfirmPasswordVisible = false;
  bool _isLoading = false;

  void showMessage(String message, {bool isError = true}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : Colors.green,
      ),
    );
  }

  bool isValidEmail(String email) {
    return RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]+$")
        .hasMatch(email);
  }

  Future<void> registerUser() async {
    // **1️⃣ Check if fields are empty**
    if (nameController.text.isEmpty ||
        emailController.text.isEmpty ||
        passwordController.text.isEmpty ||
        confirmPasswordController.text.isEmpty) {
      showMessage("All fields are required!");
      return;
    }

    // **2️⃣ Validate Email Format**
    if (!isValidEmail(emailController.text)) {
      showMessage("Invalid email format!");
      return;
    }

    // **3️⃣ Check Password Length**
    if (passwordController.text.length < 6) {
      showMessage("Password must be at least 6 characters long!");
      return;
    }

    // **4️⃣ Check Password Match**
    if (passwordController.text != confirmPasswordController.text) {
      showMessage("Passwords do not match!");
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      var url = Uri.parse("http://10.0.2.2/signspell_api/register.php");
      var response = await http.post(url, body: {
        "name": nameController.text,
        "email": emailController.text,
        "password": passwordController.text,
      });

      var data = jsonDecode(response.body);

      if (data["success"]) {
        showMessage("Registration successful!", isError: false);
        Navigator.pushNamed(context, "/login");
      } else {
        showMessage(data["message"]);
      }
    } catch (e) {
      showMessage("Failed to connect. Please check your internet.");
    }

    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // App Title
                  Text("SignSpell", style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
                  Text("Sign, Aid, Spell", style: TextStyle(fontSize: 14, color: Colors.grey)),
                  SizedBox(height: 40),

                  // Card Container
                  Container(
                    padding: EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(color: Colors.black12, blurRadius: 10, spreadRadius: 2),
                      ],
                    ),
                    child: Column(
                      children: [
                        Text("Get Started", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                        Text("Let’s get started by filling out the form below.", style: TextStyle(fontSize: 14, color: Colors.grey), textAlign: TextAlign.center),
                        SizedBox(height: 20),

                        // Input Fields
                        TextField(controller: nameController, decoration: InputDecoration(labelText: "Full Name", border: OutlineInputBorder())),
                        SizedBox(height: 10),
                        TextField(controller: emailController, decoration: InputDecoration(labelText: "Email", border: OutlineInputBorder())),
                        SizedBox(height: 10),
                        TextField(
                          controller: passwordController,
                          obscureText: !_isPasswordVisible,
                          decoration: InputDecoration(
                            labelText: "Password",
                            border: OutlineInputBorder(),
                            suffixIcon: IconButton(
                              icon: Icon(_isPasswordVisible ? Icons.visibility : Icons.visibility_off),
                              onPressed: () => setState(() => _isPasswordVisible = !_isPasswordVisible),
                            ),
                          ),
                        ),
                        SizedBox(height: 10),
                        TextField(
                          controller: confirmPasswordController,
                          obscureText: !_isConfirmPasswordVisible,
                          decoration: InputDecoration(
                            labelText: "Re-type Password",
                            border: OutlineInputBorder(),
                            suffixIcon: IconButton(
                              icon: Icon(_isConfirmPasswordVisible ? Icons.visibility : Icons.visibility_off),
                              onPressed: () => setState(() => _isConfirmPasswordVisible = !_isConfirmPasswordVisible),
                            ),
                          ),
                        ),
                        SizedBox(height: 20),

                        // Register Button
                        ElevatedButton(
                          onPressed: _isLoading ? null : registerUser,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue,
                            minimumSize: Size(double.infinity, 50),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                          child: _isLoading
                              ? CircularProgressIndicator(color: Colors.white)
                              : Text("Create Account", style: TextStyle(color: Colors.white, fontSize: 16)),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 15),

                  // Navigation to Login Page
                  GestureDetector(
                    onTap: () => Navigator.pushNamed(context, "/login"),
                    child: RichText(
                      text: TextSpan(
                        text: "Already have an account? ",
                        style: TextStyle(color: Colors.black),
                        children: [
                          TextSpan(
                            text: "Sign In here",
                            style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
